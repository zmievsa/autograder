

int returns_zero()
{
	return 0;
}

