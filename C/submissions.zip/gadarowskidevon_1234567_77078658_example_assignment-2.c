

int returns_zero()
{
	return 1;
}

