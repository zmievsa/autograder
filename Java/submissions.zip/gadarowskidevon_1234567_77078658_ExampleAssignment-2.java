
public class ExampleAssignment
{
	public static int returnsZero()
	{
		return 1;
	}
}
